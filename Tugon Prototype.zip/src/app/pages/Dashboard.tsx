import React, { useState } from 'react';
import {
  AlertTriangle, Users, CheckCircle2, Clock, TrendingUp,
  TrendingDown, Minus, Radio, MapPin, ArrowRight, Flame,
  Droplets, Car, Heart, Shield as ShieldIcon, Zap, Wind,
  ChevronRight, RefreshCw, Navigation2,
} from 'lucide-react';
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import { incidents, incidentTypeConfig, severityConfig, statusConfig } from '../data/incidents';
import { IncidentMap } from '../components/IncidentMap';
import { StatusBadge, SeverityBadge, TypeBadge } from '../components/StatusBadge';
import { useNavigate } from 'react-router';

const TREND_DATA = [
  { day: 'Feb 28', incidents: 8, resolved: 7 },
  { day: 'Mar 1', incidents: 14, resolved: 12 },
  { day: 'Mar 2', incidents: 11, resolved: 9 },
  { day: 'Mar 3', incidents: 19, resolved: 17 },
  { day: 'Mar 4', incidents: 16, resolved: 14 },
  { day: 'Mar 5', incidents: 22, resolved: 18 },
  { day: 'Mar 6', incidents: 15, resolved: 6 },
];

const TYPE_DIST = [
  { name: 'Fire', value: 4, color: '#B91C1C' },
  { name: 'Flood', value: 5, color: '#1D4ED8' },
  { name: 'Accident', value: 3, color: '#B4730A' },
  { name: 'Medical', value: 3, color: '#0F766E' },
  { name: 'Crime', value: 2, color: '#7C3AED' },
  { name: 'Infra.', value: 2, color: '#374151' },
  { name: 'Typhoon', value: 1, color: '#0369A1' },
];

const BARANGAY_DATA = [
  { name: 'Brgy. Riverside', count: 4 },
  { name: 'Brgy. Poblacion', count: 3 },
  { name: 'Brgy. San Antonio', count: 3 },
  { name: 'Brgy. Makiling', count: 2 },
  { name: 'Brgy. Santo Niño', count: 2 },
  { name: 'Brgy. Longos', count: 1 },
];

const typeIcons: Record<string, React.ReactNode> = {
  fire: <Flame size={14} />, flood: <Droplets size={14} />, accident: <Car size={14} />,
  medical: <Heart size={14} />, crime: <ShieldIcon size={14} />, infrastructure: <Zap size={14} />, typhoon: <Wind size={14} />,
};

interface KPICardProps {
  title: string; value: string | number; subtitle: string;
  icon: React.ReactNode; accent: string; trend?: { dir: 'up' | 'down' | 'flat'; val: string };
  bgLight: string;
}

function KPICard({ title, value, subtitle, icon, accent, trend, bgLight }: KPICardProps) {
  const TrendIcon = trend?.dir === 'up' ? TrendingUp : trend?.dir === 'down' ? TrendingDown : Minus;
  const trendColor = accent === '#B91C1C' ? '#B91C1C' : accent === '#059669' ? '#059669' : '#B4730A';
  return (
    <div style={{
      background: 'white',
      borderRadius: 12,
      padding: '18px 20px',
      boxShadow: '0 2px 8px rgba(0,0,0,0.07)',
      borderTop: `4px solid ${accent}`,
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      flex: 1,
      minWidth: 0,
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
        <div style={{ flex: 1 }}>
          <div style={{ color: '#64748B', fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 6 }}>{title}</div>
          <div style={{ fontSize: 30, fontWeight: 700, color: '#1E293B', lineHeight: 1 }}>{value}</div>
        </div>
        <div style={{ width: 42, height: 42, borderRadius: 10, background: bgLight, display: 'flex', alignItems: 'center', justifyContent: 'center', color: accent, flexShrink: 0 }}>
          {icon}
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ color: '#94A3B8', fontSize: 11 }}>{subtitle}</span>
        {trend && (
          <span style={{ display: 'flex', alignItems: 'center', gap: 3, fontSize: 11, fontWeight: 600, color: trendColor }}>
            <TrendIcon size={12} />
            {trend.val}
          </span>
        )}
      </div>
    </div>
  );
}

const AlertBanner = () => {
  const critical = incidents.filter(i => i.severity === 'critical' && i.status !== 'resolved');
  if (critical.length === 0) return null;
  return (
    <div style={{
      background: '#FEF2F2',
      border: '1px solid #FECACA',
      borderLeft: '4px solid #B91C1C',
      borderRadius: 8,
      padding: '10px 16px',
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 16,
    }}>
      <Radio size={16} color="#B91C1C" style={{ flexShrink: 0, animation: 'pulse 2s infinite' }} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <span style={{ color: '#B91C1C', fontWeight: 700, fontSize: 12 }}>ACTIVE ALERT: </span>
        <span style={{ color: '#7F1D1D', fontSize: 12 }}>
          {critical.length} critical incident{critical.length > 1 ? 's' : ''} requiring immediate response — {critical.map(c => c.id).join(' · ')}
        </span>
      </div>
      <span style={{
        background: '#B91C1C', color: 'white', fontSize: 9, fontWeight: 700, padding: '3px 8px',
        borderRadius: 4, letterSpacing: '0.06em', whiteSpace: 'nowrap', flexShrink: 0,
      }}>CRITICAL</span>
    </div>
  );
};

export default function Dashboard() {
  const navigate = useNavigate();
  const [selectedIncident, setSelectedIncident] = useState<typeof incidents[0] | null>(null);
  const activeIncidents = incidents.filter(i => i.status === 'active' || i.status === 'responding');
  const resolvedToday = incidents.filter(i => i.resolvedAt?.startsWith('2026-03-06'));
  const criticalCount = incidents.filter(i => i.severity === 'critical' && i.status !== 'resolved').length;

  return (
    <div style={{ padding: '14px 16px', minHeight: '100%' }}>
      {/* Alert banner */}
      <AlertBanner />

      {/* KPI Cards — 2-col grid on mobile */}
      <div className="kpi-grid" style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        <KPICard
          title="Active Incidents"
          value={activeIncidents.length}
          subtitle={`${criticalCount} critical · ${activeIncidents.filter(i => i.status === 'responding').length} responding`}
          icon={<AlertTriangle size={20} />}
          accent="#B91C1C"
          bgLight="#FEE2E2"
          trend={{ dir: 'up', val: '+3 vs. yesterday' }}
        />
        <KPICard
          title="Deployed Units"
          value={47}
          subtitle="BFP, PNP, MDRRMO, EMS"
          icon={<Users size={20} />}
          accent="#1E3A8A"
          bgLight="#DBEAFE"
          trend={{ dir: 'up', val: '+8 units' }}
        />
        <KPICard
          title="Resolved Today"
          value={resolvedToday.length}
          subtitle="Since 00:00 PHT"
          icon={<CheckCircle2 size={20} />}
          accent="#059669"
          bgLight="#D1FAE5"
          trend={{ dir: 'up', val: '+2 vs. yesterday' }}
        />
        <KPICard
          title="Avg. Response"
          value="8.3 min"
          subtitle="Target: ≤ 10 min"
          icon={<Clock size={20} />}
          accent="#B4730A"
          bgLight="#FEF3C7"
          trend={{ dir: 'down', val: '-1.2 min vs. avg' }}
        />
      </div>

      {/* Map + Live Feed Row — stacks on mobile */}
      <div className="dashboard-row" style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        {/* Map Preview */}
        <div style={{
          flex: '3 1 340px',
          background: 'white',
          borderRadius: 12,
          boxShadow: '0 2px 8px rgba(0,0,0,0.07)',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
        }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid #F1F5F9', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <MapPin size={16} color="#1E3A8A" />
              <span style={{ fontWeight: 700, color: '#1E293B', fontSize: 13 }}>Incident Overview Map</span>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4, background: '#F0FDF4', borderRadius: 5, padding: '3px 7px', border: '1px solid #BBF7D0' }}>
                <Navigation2 size={9} color="#059669" />
                <span style={{ fontSize: 9, color: '#059669', fontWeight: 600 }}>OpenStreetMap</span>
              </div>
              <button
                onClick={() => navigate('/app/map')}
                style={{
                  background: '#EFF6FF',
                  border: 'none',
                  borderRadius: 6,
                  padding: '4px 10px',
                  fontSize: 11,
                  color: '#1E3A8A',
                  fontWeight: 600,
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 4,
                }}
              >
                Full Map <ArrowRight size={11} />
              </button>
            </div>
          </div>
          <div style={{ flex: 1 }}>
            <IncidentMap
              incidents={incidents}
              height={280}
              selectedId={selectedIncident?.id}
              onSelectIncident={setSelectedIncident}
              compact={false}
              zoom={14}
            />
          </div>
          {selectedIncident && (
            <div style={{
              padding: '10px 14px',
              borderTop: '1px solid #F1F5F9',
              background: '#F8FAFC',
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              flexWrap: 'wrap',
            }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#1E293B' }}>{selectedIncident.id} — {selectedIncident.barangay}</div>
                <div style={{ fontSize: 11, color: '#64748B', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{selectedIncident.description}</div>
                <div style={{ fontSize: 9, color: '#94A3B8', marginTop: 2, fontFamily: 'monospace', display: 'flex', alignItems: 'center', gap: 4 }}>
                  <Navigation2 size={9} color="#9CA3AF" />
                  {selectedIncident.lat.toFixed(5)}°N, {selectedIncident.lng.toFixed(5)}°E
                </div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <TypeBadge type={selectedIncident.type} size="sm" />
                <SeverityBadge severity={selectedIncident.severity} size="sm" />
              </div>
            </div>
          )}
        </div>

        {/* Live Feed */}
        <div style={{
          flex: '2 1 260px',
          background: 'white',
          borderRadius: 12,
          boxShadow: '0 2px 8px rgba(0,0,0,0.07)',
          display: 'flex',
          flexDirection: 'column',
          overflow: 'hidden',
        }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid #F1F5F9', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{
                width: 8, height: 8, borderRadius: '50%',
                background: '#22C55E', display: 'inline-block',
                boxShadow: '0 0 0 3px rgba(34,197,94,0.2)',
              }} />
              <span style={{ fontWeight: 700, color: '#1E293B', fontSize: 13 }}>Live Incident Feed</span>
            </div>
            <RefreshCw size={13} color="#94A3B8" style={{ cursor: 'pointer' }} />
          </div>
          <div style={{ flex: 1, overflowY: 'auto', maxHeight: 320 }}>
            {incidents.slice(0, 10).map((inc, idx) => (
              <div
                key={inc.id}
                onClick={() => navigate('/app/incidents')}
                style={{
                  padding: '10px 14px',
                  borderBottom: '1px solid #F8FAFC',
                  cursor: 'pointer',
                  transition: 'background 0.1s',
                  display: 'flex',
                  gap: 10,
                  alignItems: 'flex-start',
                }}
                onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = '#F8FAFC'}
                onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = 'transparent'}
              >
                <div style={{
                  width: 28, height: 28, borderRadius: 8, flexShrink: 0,
                  background: incidentTypeConfig[inc.type].bgColor,
                  color: incidentTypeConfig[inc.type].color,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  {typeIcons[inc.type]}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
                    <span style={{ fontSize: 11, fontWeight: 700, color: '#1E293B' }}>{inc.id}</span>
                    <StatusBadge status={inc.status} size="sm" pulse={inc.status === 'active'} />
                  </div>
                  <div style={{ fontSize: 11, color: '#475569', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{inc.barangay}</div>
                  <div style={{ fontSize: 10, color: '#94A3B8', marginTop: 2 }}>
                    {new Date(inc.reportedAt).toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit', hour12: true })}
                  </div>
                </div>
                <SeverityBadge severity={inc.severity} size="sm" />
              </div>
            ))}
          </div>
          <div style={{ padding: '10px 14px', borderTop: '1px solid #F1F5F9', textAlign: 'center' }}>
            <button
              onClick={() => navigate('/app/incidents')}
              style={{
                background: 'none', border: 'none', color: '#1E3A8A', fontSize: 12,
                fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, margin: '0 auto',
              }}
            >
              View All Incidents <ArrowRight size={13} />
            </button>
          </div>
        </div>
      </div>

      {/* Charts Row — stacks on mobile */}
      <div className="charts-row" style={{ display: 'flex', gap: 14, marginBottom: 18, flexWrap: 'wrap' }}>
        {/* Trend Chart */}
        <div style={{ flex: '3 1 300px', background: 'white', borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.07)', padding: '14px 16px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
            <div>
              <div style={{ fontWeight: 700, color: '#1E293B', fontSize: 13 }}>7-Day Incident Trend</div>
              <div style={{ color: '#94A3B8', fontSize: 11 }}>Feb 28 – Mar 6, 2026</div>
            </div>
            <div style={{ display: 'flex', gap: 12, fontSize: 11 }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <span style={{ width: 10, height: 3, background: '#1E3A8A', display: 'inline-block', borderRadius: 2 }} />
                <span style={{ color: '#64748B' }}>Reported</span>
              </span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <span style={{ width: 10, height: 3, background: '#059669', display: 'inline-block', borderRadius: 2 }} />
                <span style={{ color: '#64748B' }}>Resolved</span>
              </span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={TREND_DATA} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" vertical={false} />
              <XAxis dataKey="day" tick={{ fontSize: 10, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: '#94A3B8' }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ borderRadius: 8, border: '1px solid #E2E8F0', fontSize: 12, boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
              />
              <Line key="line-incidents" type="monotone" dataKey="incidents" name="Reported" stroke="#1E3A8A" strokeWidth={2.5} dot={{ r: 3, fill: '#1E3A8A' }} activeDot={{ r: 5 }} isAnimationActive={false} />
              <Line key="line-resolved" type="monotone" dataKey="resolved" name="Resolved" stroke="#059669" strokeWidth={2.5} dot={{ r: 3, fill: '#059669' }} activeDot={{ r: 5 }} isAnimationActive={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Type Distribution */}
        <div style={{ flex: '2 1 220px', background: 'white', borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.07)', padding: '14px 16px' }}>
          <div style={{ fontWeight: 700, color: '#1E293B', fontSize: 13, marginBottom: 4 }}>Incident by Type</div>
          <div style={{ color: '#94A3B8', fontSize: 11, marginBottom: 10 }}>Today's distribution</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <PieChart width={120} height={120}>
              <Pie data={TYPE_DIST} cx="50%" cy="50%" innerRadius={35} outerRadius={55} paddingAngle={2} dataKey="value">
                {TYPE_DIST.map((entry, index) => (
                  <Cell key={`cell-${index}-${entry.name}`} fill={entry.color} />
                ))}
              </Pie>
            </PieChart>
            <div style={{ flex: 1 }}>
              {TYPE_DIST.map(item => (
                <div key={item.name} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 5 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ width: 8, height: 8, borderRadius: '50%', background: item.color, display: 'inline-block', flexShrink: 0 }} />
                    <span style={{ fontSize: 11, color: '#475569' }}>{item.name}</span>
                  </div>
                  <span style={{ fontSize: 11, fontWeight: 700, color: '#1E293B' }}>{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Barangay breakdown */}
        <div style={{ flex: '2 1 220px', background: 'white', borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.07)', padding: '14px 16px' }}>
          <div style={{ fontWeight: 700, color: '#1E293B', fontSize: 13, marginBottom: 4 }}>Top Affected Barangays</div>
          <div style={{ color: '#94A3B8', fontSize: 11, marginBottom: 12 }}>Incident count (current cycle)</div>
          {BARANGAY_DATA.map((b) => (
            <div key={b.name} style={{ marginBottom: 9 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
                <span style={{ fontSize: 11, color: '#475569', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: '75%' }}>{b.name}</span>
                <span style={{ fontSize: 11, fontWeight: 700, color: '#1E293B' }}>{b.count}</span>
              </div>
              <div style={{ height: 5, background: '#F1F5F9', borderRadius: 3, overflow: 'hidden' }}>
                <div style={{
                  height: '100%',
                  width: `${(b.count / BARANGAY_DATA[0].count) * 100}%`,
                  background: '#1E3A8A',
                  borderRadius: 3,
                  transition: 'width 0.5s',
                }} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Incidents Table */}
      <div style={{ background: 'white', borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.07)', overflow: 'hidden', marginBottom: 8 }}>
        <div style={{ padding: '12px 16px', borderBottom: '1px solid #F1F5F9', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontWeight: 700, color: '#1E293B', fontSize: 13 }}>Recent Incidents — March 6, 2026</span>
          <button
            onClick={() => navigate('/app/incidents')}
            style={{ background: '#EFF6FF', border: 'none', borderRadius: 8, color: '#1E3A8A', fontSize: 12, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4, padding: '8px 12px', minHeight: 40 }}
          >
            View All <ChevronRight size={13} />
          </button>
        </div>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12, minWidth: 580 }}>
            <thead>
              <tr style={{ background: '#F8FAFC' }}>
                {['Incident ID', 'Type', 'Location', 'Severity', 'Status', 'Reported', 'Responders'].map(col => (
                  <th key={col} style={{ padding: '10px 14px', textAlign: 'left', color: '#64748B', fontWeight: 600, fontSize: 11, letterSpacing: '0.04em', whiteSpace: 'nowrap', borderBottom: '1px solid #F1F5F9' }}>{col}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {incidents.slice(0, 8).map((inc, idx) => (
                <tr
                  key={inc.id}
                  style={{ borderBottom: '1px solid #F8FAFC', cursor: 'pointer', transition: 'background 0.1s' }}
                  onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = '#F8FAFC'}
                  onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = 'transparent'}
                  onClick={() => navigate('/app/incidents')}
                >
                  <td style={{ padding: '10px 14px', fontWeight: 600, color: '#1E3A8A', whiteSpace: 'nowrap' }}>{inc.id}</td>
                  <td style={{ padding: '10px 14px' }}><TypeBadge type={inc.type} size="sm" /></td>
                  <td style={{ padding: '10px 14px', color: '#475569', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{inc.barangay}</td>
                  <td style={{ padding: '10px 14px' }}><SeverityBadge severity={inc.severity} size="sm" /></td>
                  <td style={{ padding: '10px 14px' }}><StatusBadge status={inc.status} size="sm" pulse={inc.status === 'active'} /></td>
                  <td style={{ padding: '10px 14px', color: '#64748B', whiteSpace: 'nowrap' }}>
                    {new Date(inc.reportedAt).toLocaleTimeString('en-PH', { hour: '2-digit', minute: '2-digit', hour12: true })}
                  </td>
                  <td style={{ padding: '10px 14px', color: '#1E293B', fontWeight: 500 }}>{inc.responders} units</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}